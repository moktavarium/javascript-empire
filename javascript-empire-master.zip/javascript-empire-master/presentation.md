# Javascript World Domination ?

---

# Dentist
# Nurse
# Developer

---

# Software developer is the #3rd Best Job 2015

> The U.S News top 3 Best Jobs

---

# Not surprised

## Just proud to read

---

# 11

---

# 1999

---

## rue montgallet
## Windows 98
## with Paul B

---

# Segmentation Fault

> WTF !!??!

---

# coding === knitting

---

# Give me a R&D intership

> No !

---

# Airbus
## 9 Years

---

# C# and .NET

---

# Application in browser

> WTF !!??!

---

# C → C++ → Java
# Ruby → PHP → JavaScript

---

# I wanna be a Project Manager

---

# Coding for Money

---

# 92 Bond Street

---

## Android Apps
## Affiliation
## Bots
## Leboncoin...

---

# Synthesio

> Lead Frontend Developer

---

## Captain
## Best Practices Evangelist
## Happiness Coder and Bugs tracker

---

# Success stories

---

## Facebook
## Google
## Airbnb
## Blablacar
## Slack...

---

# Artis(t)an

---

# Forget the guy with a pen in his shirt pocket

---

# Web Application Architecture(s)

---

# 9 Workshops

> 4 topics

---

## 1. Javascript World Domination
## 2. How to become a superhero.js
## 3. Building Of Modern Application
## 4. API-ness

---

# Github

## [92bondstreet/javascript-empire](https://github.com/92bondstreet/javascript-empire)

---

## GMAIL

## Yassine AZZOUT

```
yassine.azzout@gmail.com
```

---

# Objective

> Be able to start an online business with a web application

---

# Methodology

---

# useful links in 3 parts

---

## Must Read
## Must Watch
## Just tell me what to do

---

# Must Read

> Useful links to read as blog post

---

# Must Watch

> talk or podcast for passive context

---

# Just tell me what to do

> To be ready the workshop day

---

# JavaScript Ecosystem

> personal commitment

---

# uncopyrighted

> Make a milion dollars if you want

---

# Web

---

# Post Facebook wall

---

# Car itinerary
## Google Maps

---

# 40 %

> 3 billions in 2014

---

# Device consumer

---

# Internet connection

---

# Open a browser

## with a specific website address

---

# Google search

---

# Send a message
### Gmail
### Facebook
### Twitter
### Instagram

---

# Buy the last bestseller
## on Amazon

---

# Application

## App

---

# Desktop

---

# Software

## program

---

# Browser

---

# Full interactive experience

---

# New software ?

---

# SAAS

> Software As A Service

---

# Web Site

---

# Static

---

# Passive eXperience

---

# Resident WWW

---

# Active
# Interaction

---

# Single task

---

# Data anywhere

---

## my or not, devices

---

# Application up to date

---

# Everywhere

---

# PC, MAC ?

## It does not matter

---

# My or not, browser

---

# Safe

---

# Les 3 frères

---

# Browser

---

# HTML

---

## Minimalist

```html
<!DOCTYPE html>
<html>
  <head>
  </head>
  <body>
  </body>
</html>
```

---

# DOM TREE

---

```html
<html>
  <head>
  </head>
  <body>
    <p>How browser works</p>
    <div>
      <span>with DOM and CSS tree</span>
    </div>
  </body>
</html>
```

---

# Render Tree

> Render tree = Dom Tree + Style Structure

---

# CSS

---

# Selectors

```css
a.nav {
  color: blue;
}

.someDiv {
  background: red;
  padding: 2em;
  border: 1px solid black;
}

h1, h2, h3 {
  font-family: tahoma;
  color: #333
}
```

---

# Javascript

> The World's Most Used Programming Language

---

# Web app programming objective

---

## Flexible
## scalable
## reusable
## maintenable
## readable

---

# * able

---

# Programming language

> `Java`, `.Net`, `PHP`, `Ruby`, `Python`, `Go`...etc.

---

# JavaScript is over

---

# Every browsers support it

----

# browser and a text editor

----

# No need SDK or Framework

---

# Everything could be done

---

# 1995

> by Brendan Eich (Netscape former)

---

## LiveScript
## JavaScript

---

# Java !== JavaScript

---

# Ecma International

---

# Last major - 6th

## ES6
## ECMAScript 2015

> (After 6 years of stability for ES5).

---

# SPA

> Single Page Application

---

## together but independently

> Gmail.

---

# client + {CMS, APP} + API + firewall + Datastore  

---

# in 1 Tweet

---

# Nearly everything in JavaScript is an object, including functions.

---

# Misunderstood

> The World's Most Misunderstood Programming Language

---

# OO Programming

> Abstraction to create models and objects.

---

# UX, UI

> UX and UI are not buzzwords

---

# Developers
## control performance, SEO, time rendering, bug free, cross-browsing of a web application

---

# user engagement

> in a competitors world

---

# Prototyping

> version 0.0 of your product

---

## Has to work and looks beautiful

> low cost best practice

---

# Notorious big

> The power of *Make it big* gives users a maximum impact.

---

![big](https://d13yacurqjgara.cloudfront.net/users/14135/screenshots/840696/attachments/88215/main3.png)

---

![big](https://d13yacurqjgara.cloudfront.net/users/30252/screenshots/2220708/attachments/412840/Settings_HD.png)

---

# Breathe

---

## Flat color

## Space

---

![Lighten](https://d13yacurqjgara.cloudfront.net/users/13307/screenshots/864910/attachments/92273/Real_Pixels.jpg)

---

# Data First

> Providing quickly information to users.

---

![data](https://d13yacurqjgara.cloudfront.net/users/3587/screenshots/2227352/attachments/414148/Day067_-_Smart_Home.jpg)

---

![data](https://d13yacurqjgara.cloudfront.net/users/13825/screenshots/1895986/attachments/323201/real-pixels.png)

---

# Micro Interaction

> But how does it work ?

---

# Motion

---

![motion](https://d13yacurqjgara.cloudfront.net/users/124059/screenshots/976474/gif2.gif)

---

![motion](https://d13yacurqjgara.cloudfront.net/users/532215/screenshots/1796852/rdc_ldp_short-term_v2_animated2.gif)

---

![motion](https://d13yacurqjgara.cloudfront.net/users/3816/screenshots/1040703/stats-animated.gif)

---

# Form

> Boring forms are everywhere

---

![forms](https://d13yacurqjgara.cloudfront.net/users/6410/screenshots/1254439/form-animation-_gif_.gif)

---

![forms](https://d13yacurqjgara.cloudfront.net/users/14827/screenshots/986398/attachments/115047/share.png)

---

# Innovating scrolling

---

![scroll](https://d13yacurqjgara.cloudfront.net/users/25514/screenshots/2121350/delivery_card.gif)

---

![scroll](https://d13yacurqjgara.cloudfront.net/users/44323/screenshots/1340425/drb-coin-animation-2.gif)

---

# Dentist
# Nurse
# Developer

---

# Tools

---

# Artisan ?

## Yes, we are.

---

# once found you can work faster and more efficient

---

# Manifesto for Software Crafmanship

---

## well-crafted software
## steadily adding value
## a community of professionals
## productive partnerships

---

# Paper and Pen

---

## Take notes
## Draw
## Cross out
## Organize
## Plan your day

---

# A good Editor

> A developer without editor is as a TV without colors: it doesn't make sense.

---

# Terminal

---

# Tmux

> Tmux enables from the same terminal screen to run a number of simultaneous and separate terminal instances.

---

# Browser

---

# Dotfiles, aliases and automation

---

# Agile

---

## Individuals and interactions
## Working software
## Customer collaboration
## Responding to change

---

# You

> Know yourself

---

## Do something to change your life, your close family and friend. The world will come after.

---

# Thank you
